import re

url_pattern = re.compile(r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+')
ip_pattern = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
datetime_pattern = re.compile(r'\b[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\b')
file_path_pattern = re.compile(r'C:\\[\w\\.-]+\\[^\s:]*')

def read_memory_dump(file_path, size=1024*1024):
    with open(file_path, 'rb') as file:
        while chunk := file.read(size):
            yield chunk

def find_artifacts(pattern, data):
    return pattern.findall(data)

def write_report(artifacts, filename):
    with open(filename, 'w', encoding='utf-8') as file:
        for artifact_type, artifact_list in artifacts.items():
            file.write(f"## {artifact_type} Found:\n")
            for artifact in artifact_list:
                file.write(f"- {artifact}\n")
            file.write("\n")

def main():
    memory_data = r'C:\Users\Student\Downloads\Tools\RamCapturer\x64\20241105.mem'
    artifacts = {
        "URLs": [],
        "IP Addresses": [],
        "Email Addresses": [],
        "Datetime Stamps": [],
        "File Paths": [],
    }
    
    for chunk in read_memory_dump(memory_data):
        chunk_data = chunk.decode(errors='ignore') 
        artifacts["URLs"].extend(find_artifacts(url_pattern, chunk_data))
        artifacts["IP Addresses"].extend(find_artifacts(ip_pattern, chunk_data))
        artifacts["Email Addresses"].extend(find_artifacts(email_pattern, chunk_data))
        artifacts["Datetime Stamps"].extend(find_artifacts(datetime_pattern, chunk_data))
        artifacts["File Paths"].extend(find_artifacts(file_path_pattern, chunk_data))

    file_path = r'C:\Users\Student\Downloads\Tools\RamCapturer\x64\forensic_report.txt'

    write_report(artifacts, file_path)

    print("Success!")
if __name__ == "__main__":
    main()
